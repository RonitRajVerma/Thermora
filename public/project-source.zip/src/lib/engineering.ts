// Engineering models for THERMORA

/**
 * Calculates IT energy (E_IT)
 * P_active = P_IT * utilization
 * E_IT = P_active * operating_hours
 */
export function calculateITEnergy(maxPowerMW: number, utilizationPercent: number, hours: number) {
  const activePower = maxPowerMW * (utilizationPercent / 100);
  return activePower * hours; // MWh
}

/**
 * Calculates Thermal Energy (E_thermal)
 * Assumption: E_thermal = E_IT
 */
export function calculateThermalEnergy(energyIT: number) {
  return energyIT; // MWh
}

/**
 * Calculates Recoverable Heat (Q_recoverable)
 */
export function calculateRecoverableHeat(thermalEnergy: number, recoverableFraction: number) {
  return thermalEnergy * recoverableFraction;
}

/**
 * Calculates Vapor Pressure of Water (Antoine Equation approximation for water)
 * T in Celsius, returns pressure in kPa
 */
export function calculateVaporPressure(T: number): number {
  // Antoine parameters for water (T in C, P in mmHg)
  // A = 8.07131, B = 1730.63, C = 233.426
  // P = 10^(A - B/(C+T))
  const A = 8.07131;
  const B = 1730.63;
  const C = 233.426;
  
  if (T < 1 || T > 100) return 0; // Simple bounds check for model validity
  
  const p_mmHg = Math.pow(10, A - (B / (C + T)));
  return p_mmHg * 0.133322; // Convert mmHg to kPa
}

/**
 * Saline vapor pressure
 * Pw = aw * Psat
 */
export function calculateSalineVaporPressure(T: number, salinityPPM: number): number {
  const psat = calculateVaporPressure(T);
  // Very rough approximation of water activity (aw) based on salinity
  // aw decreases as salinity increases. Seawater (~35000 ppm) aw is ~0.98.
  const aw = 1 - (salinityPPM * 0.00000057);
  return psat * aw;
}

/**
 * Calculates MD Driving Force (ΔPv)
 */
export function calculateMDDrivingForce(tHot: number, tCold: number, feedSalinityPPM: number): number {
  const pHot = calculateSalineVaporPressure(tHot, feedSalinityPPM);
  const pCold = calculateVaporPressure(tCold); // Permeate is fresh
  return Math.max(0, pHot - pCold);
}

/**
 * Calculates MD Flux (J)
 * J = Km * ΔPv
 * Returns kg/m^2/h
 */
export function calculateMDFlux(km: number, drivingForce: number): number {
  return km * drivingForce;
}

/**
 * Calculates MD Production
 * m_dot = J * membrane_area
 * returns L/h (kg/h ~ L/h)
 */
export function calculateMDProduction(flux: number, area: number): number {
  return flux * area;
}

/**
 * Calculates RO Production
 * R_RO = freshwater_output / feed_input
 */
export function calculateROProduction(feedVol: number, recoveryRate: number): number {
  return feedVol * recoveryRate; // Return L/h
}

export function calculateHybridRecovery(
  feedVolLph: number,
  roRecoveryRate: number, 
  tHot: number, 
  tCold: number, 
  salinityPPM: number, 
  km: number, 
  membraneArea: number
) {
  // RO Stage
  const w_RO = calculateROProduction(feedVolLph, roRecoveryRate);
  const ro_concentrate = feedVolLph - w_RO;
  const ro_concentrate_salinity = (feedVolLph * salinityPPM) / ro_concentrate;
  
  // MD Stage
  const drivingForce = calculateMDDrivingForce(tHot, tCold, ro_concentrate_salinity);
  const flux = calculateMDFlux(km, drivingForce);
  let w_MD = calculateMDProduction(flux, membraneArea);
  
  // Cap MD production to available concentrate
  if (w_MD > ro_concentrate) w_MD = ro_concentrate;
  
  return {
    feedLph: feedVolLph,
    roWaterLph: w_RO,
    mdWaterLph: w_MD,
    totalWaterLph: w_RO + w_MD,
    roConcentrateLph: ro_concentrate,
    roConcentrateSalinityPPM: ro_concentrate_salinity,
    mdFlux: flux,
    remainingBrineLph: ro_concentrate - w_MD
  };
}
