import { GoogleGenAI } from "@google/genai";
import { calculateHybridRecovery, calculateITEnergy } from "./engineering";

const apiKey = process.env.GEMINI_API_KEY;

export const ai = apiKey
  ? new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    })
  : null;

// The AI tool registry
export const aiTools = {
  calculate_hybrid_recovery: calculateHybridRecovery,
  calculate_it_energy: calculateITEnergy,
};
