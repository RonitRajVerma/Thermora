import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Sparkles, 
  Cpu, 
  Send, 
  Check, 
  Terminal, 
  Copy, 
  X,
  ArrowRight
} from "lucide-react";
import { useTelemetry } from "../hooks/useTelemetry";
import { SystemFlowSimulation } from "./SystemFlowSimulation";

export function ThermoraHero() {
  const { 
    telemetry, 
    isHardwareLive,
    isSimulationActive,
    startSimulation,
    stopSimulation
  } = useTelemetry();

  // Active view: null (only the 2 buttons), "simulation" (the 60-FPS process flow), or "hardware" (ESP32 node)
  const [activeMode, setActiveMode] = useState<"simulation" | "hardware" | null>(null);

  // Hardware test packet states
  const [copied, setCopied] = useState<boolean>(false);
  const [pingSending, setPingSending] = useState<boolean>(false);
  const [pingSuccess, setPingSuccess] = useState<boolean>(false);

  const sendTestPacket = async () => {
    setPingSending(true);
    setPingSuccess(false);
    try {
      const simulatedTemp = Number((26.2 + Math.random() * 2).toFixed(1));
      const simulatedHumidity = Number((50 + Math.random() * 6).toFixed(1));
      const res = await fetch("/api/telemetry", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          deviceId: "ESP32-DHT11",
          temperature: simulatedTemp,
          humidity: simulatedHumidity
        })
      });
      if (res.ok) {
        setPingSuccess(true);
        setTimeout(() => setPingSuccess(false), 4000);
      }
    } catch (err) {
      console.error("Failed to post telemetry", err);
    } finally {
      setPingSending(false);
    }
  };

  const origin = typeof window !== 'undefined' ? window.location.origin : '';
  const curlCommand = `curl -X POST ${origin}/api/telemetry \\
  -H "Content-Type: application/json" \\
  -d '{"deviceId":"ESP32-DHT11","temperature":26.5,"humidity":52.0}'`;

  const copyCurl = () => {
    navigator.clipboard.writeText(curlCommand);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div 
      id="thermora-homepage"
      className="max-w-5xl mx-auto px-4 py-8 sm:py-16 flex flex-col items-center"
      style={{ fontFamily: 'Arial, Helvetica, sans-serif' }}
    >
      
      {/* 1. Project Name & Tagline */}
      <div className="text-center space-y-3 mb-10">
        <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight text-white uppercase drop-shadow-[0_0_25px_rgba(6,182,212,0.25)]">
          THERMORA
        </h1>
        <p className="text-xl sm:text-2xl font-bold text-cyan-300">
          Burn Tokens, Make Water.
        </p>
        <p className="text-sm sm:text-base text-slate-400 max-w-xl mx-auto leading-relaxed">
          Transform AI datacenter waste heat into clean drinking water through closed-loop membrane distillation.
        </p>
      </div>

      {/* 2. ONLY THAT TWO BUTTONS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6 w-full max-w-2xl mb-8">
        
        {/* Button 1: Burn Tokens -> Generate Water */}
        <button
          onClick={() => setActiveMode((prev) => (prev === "simulation" ? null : "simulation"))}
          className={`relative rounded-2xl p-5 sm:p-6 flex items-center gap-4 sm:gap-5 transition-all duration-200 border text-left cursor-pointer ${
            activeMode === "simulation"
              ? "bg-[#07212e] border-cyan-400 shadow-[0_0_30px_rgba(6,182,212,0.3)] ring-2 ring-cyan-400/50 scale-[1.01]"
              : "bg-[#061822] border-cyan-500/30 hover:border-cyan-400 hover:shadow-[0_0_20px_rgba(6,182,212,0.2)] hover:bg-[#08202d]"
          }`}
        >
          <div className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 transition-colors ${
            activeMode === "simulation"
              ? "bg-cyan-500 text-slate-950 font-bold shadow-[0_0_15px_rgba(6,182,212,0.5)]"
              : "bg-cyan-500/20 text-cyan-300 border border-cyan-400/30"
          }`}>
            <Sparkles size={22} />
          </div>
          <div className="flex-1">
            <div className="text-xs font-bold uppercase tracking-wider text-cyan-400">
              Process Flow
            </div>
            <div className="text-base sm:text-lg font-bold text-white mt-0.5">
              Burn Tokens → Generate Water
            </div>
            <div className="text-xs text-slate-400 mt-0.5">
              {activeMode === "simulation" ? "Click to collapse simulation" : "Launch 60-FPS system flow diagram"}
            </div>
          </div>
        </button>

        {/* Button 2: Real Simulation -> Connect ESP32 */}
        <button
          onClick={() => setActiveMode((prev) => (prev === "hardware" ? null : "hardware"))}
          className={`relative rounded-2xl p-5 sm:p-6 flex items-center gap-4 sm:gap-5 transition-all duration-200 border text-left cursor-pointer ${
            activeMode === "hardware"
              ? "bg-[#0c1f2b] border-slate-300 shadow-[0_0_30px_rgba(255,255,255,0.15)] ring-2 ring-white/30 scale-[1.01]"
              : "bg-[#061822] border-white/15 hover:border-white/30 hover:shadow-md hover:bg-[#091f2c]"
          }`}
        >
          <div className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 transition-colors ${
            activeMode === "hardware"
              ? "bg-white text-slate-950 font-bold shadow-md"
              : "bg-white/10 text-slate-300 border border-white/15"
          }`}>
            <Cpu size={22} />
          </div>
          <div className="flex-1">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
                Hardware Node
              </span>
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                isHardwareLive 
                  ? "bg-emerald-950/80 text-emerald-300 border border-emerald-400/40" 
                  : isSimulationActive 
                  ? "bg-cyan-950/80 text-cyan-300 border border-cyan-400/40" 
                  : "bg-white/5 text-slate-400 border border-white/10"
              }`}>
                {isHardwareLive ? "LIVE" : isSimulationActive ? "SIMULATED" : "OFFLINE"}
              </span>
            </div>
            <div className="text-base sm:text-lg font-bold text-white mt-0.5">
              Real Simulation → Connect ESP32
            </div>
            <div className="text-xs text-slate-400 mt-0.5">
              {activeMode === "hardware" ? "Click to collapse node status" : "Microcontroller telemetry & test"}
            </div>
          </div>
        </button>

      </div>

      {/* 3. DYNAMIC CONTENT: Only appears after clicking one of the two buttons */}
      <div className="w-full max-w-4xl">
        <AnimatePresence mode="wait">
          
          {/* Mode 1: The Requested Amazing Simulation Flow */}
          {activeMode === "simulation" && (
            <motion.div
              key="simulation-view"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.25 }}
              className="w-full"
            >
              <SystemFlowSimulation onClose={() => setActiveMode(null)} />
            </motion.div>
          )}

          {/* Mode 2: Hardware Telemetry / ESP32 Status */}
          {activeMode === "hardware" && (
            <motion.div
              key="hardware-view"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.25 }}
              className="w-full bg-[#061822] border border-cyan-500/30 rounded-3xl p-6 sm:p-8 space-y-6 shadow-[0_20px_60px_rgba(0,0,0,0.8)] text-slate-100"
            >
              {/* Header */}
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-white/10 pb-4">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-lg font-bold text-white">ESP32 Hardware Node Telemetry</h3>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                      isHardwareLive 
                        ? "bg-emerald-950/80 text-emerald-300 border border-emerald-400/40" 
                        : isSimulationActive
                        ? "bg-cyan-950/80 text-cyan-300 border border-cyan-400/40"
                        : "bg-white/5 text-slate-400 border border-white/10"
                    }`}>
                      {isHardwareLive ? "LIVE MEASURED" : isSimulationActive ? "SIMULATED FEED" : "NODE OFFLINE"}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-1">
                    {isHardwareLive 
                      ? `Receiving live telemetry from device ${telemetry?.deviceId || "ESP32"}`
                      : isSimulationActive
                      ? "Software simulation active. Telemetry is modelled."
                      : "Connect physical ESP32 or trigger simulated telemetry."}
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  {!isHardwareLive && (
                    <button
                      onClick={isSimulationActive ? stopSimulation : startSimulation}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        isSimulationActive
                          ? "bg-rose-950/80 text-rose-300 border border-rose-500/40 hover:bg-rose-900/80"
                          : "bg-white/5 text-slate-300 hover:bg-white/10 border border-white/15"
                      }`}
                    >
                      {isSimulationActive ? "Stop Simulation" : "Start Software Simulation"}
                    </button>
                  )}

                  <button
                    onClick={sendTestPacket}
                    disabled={pingSending}
                    className="px-3.5 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition-all flex items-center gap-1.5 disabled:opacity-50 cursor-pointer shadow-[0_0_15px_rgba(6,182,212,0.4)]"
                  >
                    <Send size={12} className={pingSending ? "animate-spin" : ""} />
                    <span>Send Test Packet</span>
                  </button>

                  <button
                    onClick={() => setActiveMode(null)}
                    className="p-1.5 rounded-lg bg-white/5 hover:bg-white/15 text-slate-400 hover:text-white transition-colors cursor-pointer"
                    title="Close"
                  >
                    <X size={15} />
                  </button>
                </div>
              </div>

              {pingSuccess && (
                <div className="p-3.5 rounded-xl bg-emerald-950/70 border border-emerald-400/40 text-emerald-200 text-xs flex items-center gap-2 font-medium">
                  <Check size={16} className="text-emerald-400 shrink-0" />
                  <span>Telemetry packet delivered to /api/telemetry. Device switched to LIVE.</span>
                </div>
              )}

              {/* Measured Physical Sensors */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                
                <div className="p-5 rounded-2xl bg-[#020b12] border border-white/10 flex flex-col justify-between h-32">
                  <div className="flex items-center justify-between text-xs text-slate-400 font-semibold">
                    <span>DHT11 Temperature</span>
                    <span className="text-[10px] uppercase font-bold text-slate-500">
                      {isHardwareLive ? "[MEASURED]" : isSimulationActive ? "[MODELLED]" : "[NO TELEMETRY]"}
                    </span>
                  </div>
                  <div className="flex items-baseline gap-1.5 my-auto">
                    <span className="text-4xl font-extrabold text-white">
                      {isHardwareLive && telemetry?.ambientTemperature != null
                        ? telemetry.ambientTemperature.toFixed(1)
                        : isSimulationActive && telemetry?.temperature != null
                        ? telemetry.temperature.toFixed(1)
                        : "—"}
                    </span>
                    <span className="text-sm font-semibold text-slate-400">°C</span>
                  </div>
                  <div className="text-[11px] text-slate-500">
                    Chamber ambient thermal readout
                  </div>
                </div>

                <div className="p-5 rounded-2xl bg-[#020b12] border border-white/10 flex flex-col justify-between h-32">
                  <div className="flex items-center justify-between text-xs text-slate-400 font-semibold">
                    <span>DHT11 Relative Humidity</span>
                    <span className="text-[10px] uppercase font-bold text-slate-500">
                      {isHardwareLive ? "[MEASURED]" : isSimulationActive ? "[MODELLED]" : "[NO TELEMETRY]"}
                    </span>
                  </div>
                  <div className="flex items-baseline gap-1.5 my-auto">
                    <span className="text-4xl font-extrabold text-cyan-400">
                      {isHardwareLive && telemetry?.humidity != null
                        ? telemetry.humidity.toFixed(0)
                        : isSimulationActive && telemetry?.humidity != null
                        ? telemetry.humidity.toFixed(0)
                        : "—"}
                    </span>
                    <span className="text-sm font-semibold text-slate-400">% RH</span>
                  </div>
                  <div className="text-[11px] text-slate-500">
                    Chamber relative humidity sensor
                  </div>
                </div>

              </div>

              {/* cURL Endpoint Command */}
              <div className="p-4 rounded-2xl bg-[#020b12] border border-white/10 text-slate-100 text-xs">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2 font-semibold">
                    <Terminal size={14} className="text-cyan-400" />
                    <span>Send packet via cURL from any terminal:</span>
                  </div>
                  <button
                    onClick={copyCurl}
                    className="px-2.5 py-1 rounded-md bg-white/10 hover:bg-white/20 text-slate-200 hover:text-white text-[11px] transition-colors flex items-center gap-1 cursor-pointer"
                  >
                    {copied ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                    <span>{copied ? "Copied" : "Copy"}</span>
                  </button>
                </div>
                <pre className="text-emerald-300 font-mono text-[11px] overflow-x-auto leading-relaxed p-2 bg-black/60 border border-white/5 rounded-lg">
                  {curlCommand}
                </pre>
              </div>

            </motion.div>
          )}

        </AnimatePresence>
      </div>

    </div>
  );
}
