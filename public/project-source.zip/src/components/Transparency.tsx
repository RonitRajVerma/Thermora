import React from "react";

export function Transparency() {
  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-5xl mx-auto space-y-6">
      <header className="pb-3 border-b border-white/10 space-y-1">
        <div className="flex items-center gap-2 text-xs font-mono text-cyan-400">
          <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
          <span>PROVENANCE &amp; METHODOLOGY</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
          Transparency &amp; Provenance
        </h1>
        <p className="text-xs sm:text-sm text-slate-400">
          Mathematical engines, scientific literature grounding, and evidence classification.
        </p>
      </header>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-6">
          <Section title="Model Versions &amp; Engines">
            <Item label="RO Engine" value="RO-v0.1 (Van 't Hoff derivation)" />
            <Item label="MD Engine" value="MD-v0.1 (Hollow-fiber DCMD)" />
            <Item label="Hybrid Systems Logic" value="HYBRID-v0.1 (Closed mass balance)" />
            <Item label="Vapor Pressure Equation" value="Antoine Saturation Model" />
          </Section>

          <Section title="Evidence Classification">
            <div className="space-y-3">
               <BadgeRow type="MEASURED" desc="Hardware telemetry (ESP32 / ESP8266) from physical prototype." color="text-emerald-400 border-emerald-500/30 bg-emerald-950/40" />
               <BadgeRow type="VERIFIED" desc="Peer-reviewed literature (Desalination journal / ASHRAE)." color="text-sky-400 border-sky-500/30 bg-sky-950/40" />
               <BadgeRow type="CALCULATED" desc="Closed-form deterministic mass and energy conservation." color="text-slate-300 border-slate-700 bg-slate-800/60" />
               <BadgeRow type="MODELLED" desc="Scenario simulations parameterized to server thermal loads." color="text-cyan-300 border-cyan-500/30 bg-cyan-950/40" />
               <BadgeRow type="ASSUMED" desc="Explicit user or engineering constant assumptions." color="text-amber-300 border-amber-500/30 bg-amber-950/40" />
            </div>
          </Section>
        </div>

        <div className="space-y-6">
          <Section title="Core Thermodynamic Assumptions">
            <ul className="list-disc list-inside text-xs text-slate-300 space-y-2.5 font-mono leading-relaxed">
              <li>100% of compute IT load is converted to thermal energy (E_thermal ≈ E_IT).</li>
              <li>70% recoverable heat fraction limits total accessible thermal energy via direct-to-chip cold plates.</li>
              <li>Raoult-modified water activity (aw) approximation used for high-salinity vapor pressure suppression.</li>
              <li>MD driving force assumes counter-current cross-flow with boundary layer mass transfer polarization.</li>
              <li>High-salinity RO concentrate directly forms the feed stream for the MD distillation stage.</li>
            </ul>
          </Section>

          <div className="border border-cyan-500/20 bg-[#061822] p-5 rounded-2xl text-xs text-slate-400 leading-relaxed font-mono shadow-lg">
            <strong className="text-cyan-400">DISCLAIMER:</strong> This platform is designed to simulate and model the coupled relationship between compute, waste heat, and decentralized water recovery. Modelled yields should not be interpreted as guaranteed physical production without site-specific pilot data and localized ambient wet-bulb calibration. MD flux coefficients (Km) are calibrated per hydrophobic PTFE membrane specifications.
          </div>
        </div>
      </div>
    </div>
  );
}

function Section({ title, children }: { title: string, children: React.ReactNode }) {
  return (
    <div className="border border-cyan-500/20 bg-[#061822] p-5 rounded-2xl shadow-lg space-y-3">
      <h3 className="text-xs text-cyan-400 font-bold tracking-wider uppercase border-b border-white/5 pb-2.5">{title}</h3>
      <div className="space-y-2">{children}</div>
    </div>
  );
}

function Item({ label, value }: { label: string, value: string }) {
  return (
    <div className="flex justify-between items-center py-1.5 border-b border-white/5 last:border-0">
      <span className="text-xs text-slate-400 font-medium">{label}</span>
      <span className="text-xs font-mono text-white">{value}</span>
    </div>
  );
}

function BadgeRow({ type, desc, color }: { type: string, desc: string, color: string }) {
  return (
    <div className="flex gap-3 items-start">
      <span className={`text-[10px] font-mono px-2 py-0.5 rounded uppercase tracking-wider border ${color} w-24 text-center shrink-0 font-bold`}>
        {type}
      </span>
      <span className="text-xs text-slate-400 flex-1 pt-0.5 leading-normal">{desc}</span>
    </div>
  );
}
