import React, { useState, useMemo } from "react";
import { 
  Droplets, 
  Flame, 
  Leaf, 
  HelpCircle, 
  ChevronDown, 
  ChevronUp 
} from "lucide-react";

export function Impact() {
  const [capacityMW, setCapacityMW] = useState<number>(100);
  const [showAssumptions, setShowAssumptions] = useState<boolean>(false);

  const presets = [
    { label: "10 MW Pilot", value: 10 },
    { label: "50 MW Regional", value: 50 },
    { label: "100 MW Hyperscale", value: 100 },
    { label: "200 MW Campus", value: 200 },
  ];

  const metrics = useMemo(() => {
    const mw = capacityMW;
    const utilization = 0.80; // 80% average continuous load
    const activeMW = mw * utilization;
    
    // 70% direct-to-chip heat capture
    const thermalMWt = activeMW * 0.70;
    
    // Freshwater recovery yield: ~8,640 L/day per MW capacity (360 L/h per MW active)
    const waterYieldLpd = mw * 8640;
    const waterYieldM3Yr = (waterYieldLpd * 365) / 1000;
    
    // One meaningful equivalence: WHO 50 L/person/day minimum domestic water access
    const peopleDailyWater = Math.round(waterYieldLpd / 50);

    return {
      activeMW,
      thermalMWt,
      waterYieldLpd,
      waterYieldM3Yr,
      peopleDailyWater,
    };
  }, [capacityMW]);

  return (
    <div className="min-h-[calc(100vh-4rem)] p-4 sm:p-6 lg:p-8 max-w-4xl mx-auto space-y-8">
      
      {/* Header */}
      <header className="pb-3 border-b border-white/10 space-y-1">
        <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
          <span>RESOURCE RECOVERY PROJECTIONS</span>
          <span className="text-slate-600">•</span>
          <span>[MODELLED SCENARIO]</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
          Impact &amp; Sustainability
        </h1>
        <p className="text-xs sm:text-sm text-slate-400">
          Modelled heat recovery and freshwater generation potential for AI datacenters.
        </p>
      </header>

      {/* Capacity Slider & Presets */}
      <section className="bg-[#061822] border border-cyan-500/20 rounded-2xl p-5 space-y-4 shadow-lg">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <span className="text-xs font-bold text-white uppercase tracking-wider">
              Datacenter Capacity
            </span>
            <div className="text-2xl font-mono font-bold text-white mt-0.5">
              {capacityMW} MW <span className="text-xs text-slate-400 font-normal">({metrics.activeMW.toFixed(0)} MW active @ 80% load)</span>
            </div>
          </div>

          <div className="flex items-center gap-1.5 bg-[#020b12] p-1 rounded-xl border border-white/5">
            {presets.map((preset) => (
              <button
                key={preset.value}
                onClick={() => setCapacityMW(preset.value)}
                className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors ${
                  capacityMW === preset.value
                    ? "bg-cyan-500/20 text-cyan-300 font-semibold border border-cyan-400/30"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                {preset.label}
              </button>
            ))}
          </div>
        </div>

        <input
          type="range"
          min="10"
          max="200"
          step="10"
          value={capacityMW}
          onChange={(e) => setCapacityMW(Number(e.target.value))}
          className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
        />
      </section>

      {/* The 4 Strongest Metrics answering:
          1. How much heat can we recover?
          2. How much water could that produce?
          3. What is the potential impact? */}
      <section className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        
        {/* Metric 1: Waste heat reused */}
        <div className="bg-[#061822] border border-cyan-500/20 rounded-2xl p-6 flex flex-col justify-between h-40 shadow-lg">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="text-amber-400 font-medium">1. Heat Recoverable</span>
            <span className="font-mono text-[10px] text-amber-400/80">[MODELLED]</span>
          </div>
          <div>
            <div className="text-3xl sm:text-4xl font-mono font-bold text-white">
              {metrics.thermalMWt.toFixed(1)} <span className="text-base text-slate-400 font-normal">MWt</span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Continuous thermal energy captured from server liquid cold plates at 50°C return.
            </p>
          </div>
        </div>

        {/* Metric 2: Water recovery daily */}
        <div className="bg-[#061822] border border-cyan-500/20 rounded-2xl p-6 flex flex-col justify-between h-40 shadow-lg">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="text-cyan-400 font-medium">2. Daily Water Recovery</span>
            <span className="font-mono text-[10px] text-cyan-400/80">[PROJECTED]</span>
          </div>
          <div>
            <div className="text-3xl sm:text-4xl font-mono font-bold text-white">
              {metrics.waterYieldLpd.toLocaleString()} <span className="text-base text-slate-400 font-normal">L/day</span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Freshwater recovered via hybrid RO + Membrane Distillation without boiler penalty.
            </p>
          </div>
        </div>

        {/* Metric 3: Annual water recovery */}
        <div className="bg-[#061822] border border-cyan-500/20 rounded-2xl p-6 flex flex-col justify-between h-40 shadow-lg">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="text-teal-400 font-medium">3. Annual Water Production</span>
            <span className="font-mono text-[10px] text-teal-400/80">[PROJECTED]</span>
          </div>
          <div>
            <div className="text-3xl sm:text-4xl font-mono font-bold text-white">
              {metrics.waterYieldM3Yr.toLocaleString()} <span className="text-base text-slate-400 font-normal">m³/year</span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Net annual freshwater volume returned to industrial or municipal distribution.
            </p>
          </div>
        </div>

        {/* Metric 4: One meaningful equivalence */}
        <div className="bg-[#061822] border border-cyan-500/20 rounded-2xl p-6 flex flex-col justify-between h-40 shadow-lg">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="text-emerald-400 font-medium">4. Community Water Supply</span>
            <span className="font-mono text-[10px] text-emerald-400/80">[SCENARIO ESTIMATE]</span>
          </div>
          <div>
            <div className="text-3xl sm:text-4xl font-mono font-bold text-white">
              ~{metrics.peopleDailyWater.toLocaleString()} <span className="text-base text-slate-400 font-normal">people</span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Daily essential domestic water needs met (based on WHO 50 Liters/day baseline).
            </p>
          </div>
        </div>

      </section>

      {/* Small "Calculation / Assumptions" Interaction */}
      <section className="bg-[#061822] border border-cyan-500/20 rounded-2xl overflow-hidden shadow-lg">
        <button
          onClick={() => setShowAssumptions(!showAssumptions)}
          className="w-full px-5 py-3.5 flex items-center justify-between text-left text-xs text-slate-300 hover:text-white transition-colors cursor-pointer"
        >
          <div className="flex items-center gap-2 font-mono">
            <HelpCircle size={14} className="text-slate-400" />
            <span>Calculation Parameters &amp; Model Assumptions</span>
          </div>
          {showAssumptions ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
        </button>

        {showAssumptions && (
          <div className="px-5 pb-5 pt-1 border-t border-white/5 text-xs text-slate-400 space-y-2 font-mono">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              <div className="p-3 rounded-xl bg-[#060a12] border border-white/5 space-y-1">
                <div className="text-white font-semibold">Datacenter Utilization: 80%</div>
                <div>Continuous IT workload load factor across hyperscale clusters.</div>
              </div>
              <div className="p-3 rounded-xl bg-[#060a12] border border-white/5 space-y-1">
                <div className="text-white font-semibold">Heat Capture Ratio: 70%</div>
                <div>Direct-to-chip cold plate liquid loop recovery at 50°C return.</div>
              </div>
              <div className="p-3 rounded-xl bg-[#060a12] border border-white/5 space-y-1">
                <div className="text-white font-semibold">Desalination Yield: 8,640 L/day/MW</div>
                <div>Calibrated for hybrid RO + MD coupling with 35,000 ppm seawater feed.</div>
              </div>
              <div className="p-3 rounded-xl bg-[#060a12] border border-white/5 space-y-1">
                <div className="text-white font-semibold">WHO Baseline: 50 L/capita/day</div>
                <div>Standard metric for basic domestic drinking, cooking, and hygiene water access.</div>
              </div>
            </div>
            <p className="text-[11px] text-slate-500 pt-2 font-sans">
              *All figures shown are engineering model projections. Actual performance varies with IT utilization, local ambient wet-bulb temperatures, and feedwater salinity.
            </p>
          </div>
        )}
      </section>

    </div>
  );
}
