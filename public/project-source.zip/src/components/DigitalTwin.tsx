import React, { useState, useMemo } from "react";
import { useTelemetry } from "../hooks/useTelemetry";
import {
  calculateHybridRecovery,
  calculateMDDrivingForce,
  calculateVaporPressure,
} from "../lib/engineering";
import {
  Cpu,
  Flame,
  Droplets,
  Waves,
  ArrowRight,
  Info
} from "lucide-react";
import { motion } from "motion/react";

interface SimParams {
  itLoadMW: number;
  tHot: number;
  tCold: number;
  feedVolLph: number;
  roRecoveryRate: number;
  feedSalinity: number;
  km: number;
  membraneArea: number;
}

const presets = [
  { label: "10 MW Edge", mw: 10, feed: 15000, tHot: 50, area: 1500 },
  { label: "50 MW Regional", mw: 50, feed: 50000, tHot: 52, area: 4500 },
  { label: "100 MW Hyperscale", mw: 100, feed: 100000, tHot: 55, area: 8000 },
];

export function DigitalTwin() {
  const { telemetry } = useTelemetry();

  const [params, setParams] = useState<SimParams>({
    itLoadMW: 80,
    tHot: 50,
    tCold: 20,
    feedVolLph: 50000,
    roRecoveryRate: 0.5,
    feedSalinity: 35000,
    km: 2.5e-7,
    membraneArea: 6000,
  });

  const handleParamChange = (key: keyof SimParams, value: number) => {
    setParams((prev) => ({ ...prev, [key]: value }));
  };

  const applyPreset = (preset: (typeof presets)[0]) => {
    setParams((prev) => ({
      ...prev,
      itLoadMW: preset.mw,
      feedVolLph: preset.feed,
      tHot: preset.tHot,
      membraneArea: preset.area,
    }));
  };

  const sim = useMemo(() => {
    const activeMW = params.itLoadMW;
    const thermalMWt = activeMW * 0.70; // 70% direct-to-chip heat recovery assumption

    const hybrid = calculateHybridRecovery(
      params.feedVolLph,
      params.roRecoveryRate,
      params.tHot,
      params.tCold,
      params.feedSalinity,
      params.km,
      params.membraneArea
    );

    const deltaPv = calculateMDDrivingForce(params.tHot, params.tCold, hybrid.roConcentrateSalinityPPM);
    const totalRecoveryPct = (hybrid.totalWaterLph / params.feedVolLph) * 100;
    const roSharePct = (hybrid.roWaterLph / params.feedVolLph) * 100;
    const mdSharePct = (hybrid.mdWaterLph / params.feedVolLph) * 100;
    const brineSharePct = (hybrid.remainingBrineLph / params.feedVolLph) * 100;

    return {
      activeMW,
      thermalMWt,
      hybrid,
      deltaPv,
      totalRecoveryPct,
      roSharePct,
      mdSharePct,
      brineSharePct,
    };
  }, [params]);

  return (
    <div className="min-h-[calc(100vh-4rem)] p-4 sm:p-6 lg:p-8 max-w-5xl mx-auto space-y-6">
      
      {/* Header */}
      <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-3 border-b border-white/10">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-400 font-mono mb-1">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
            <span>THERMODYNAMIC SIMULATION</span>
            <span className="text-slate-600">•</span>
            <span className="text-slate-400 font-sans">[MODELLED SCENARIO]</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
            Digital Twin
          </h1>
          <p className="text-slate-400 text-xs sm:text-sm mt-0.5">
            Mass and energy balance for server direct-to-chip heat reuse.
          </p>
        </div>

        {/* Presets */}
        <div className="flex items-center gap-1.5 bg-[#061822] p-1 rounded-xl border border-cyan-500/20">
          {presets.map((preset) => (
            <button
              key={preset.mw}
              onClick={() => applyPreset(preset)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                params.itLoadMW === preset.mw
                  ? "bg-cyan-500/20 text-cyan-300 font-semibold border border-cyan-400/30"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              {preset.label}
            </button>
          ))}
        </div>
      </header>

      {/* Core Flow Bar: COMPUTE → HEAT EXCHANGER → RO → RO CONCENTRATE → MD → WATER */}
      <div className="p-3.5 rounded-xl bg-[#061822] border border-cyan-500/20 flex items-center justify-between text-xs text-slate-300 font-medium overflow-x-auto">
        <div className="flex items-center gap-1.5 shrink-0">
          <span className="w-1.5 h-1.5 rounded-full bg-orange-400" />
          <span>Compute ({params.itLoadMW} MW)</span>
        </div>
        <ArrowRight size={13} className="text-slate-600 shrink-0 mx-2" />
        <div className="flex items-center gap-1.5 shrink-0">
          <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
          <span>Heat Exchanger ({params.tHot}°C)</span>
        </div>
        <ArrowRight size={13} className="text-slate-600 shrink-0 mx-2" />
        <div className="flex items-center gap-1.5 shrink-0">
          <span className="w-1.5 h-1.5 rounded-full bg-sky-400" />
          <span>RO Primary Stage</span>
        </div>
        <ArrowRight size={13} className="text-slate-600 shrink-0 mx-2" />
        <div className="flex items-center gap-1.5 shrink-0">
          <span className="w-1.5 h-1.5 rounded-full bg-teal-400" />
          <span>MD Concentration</span>
        </div>
        <ArrowRight size={13} className="text-slate-600 shrink-0 mx-2" />
        <div className="flex items-center gap-1.5 shrink-0 text-cyan-300 font-semibold">
          <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
          <span>Water ({sim.hybrid.totalWaterLph.toLocaleString()} L/h)</span>
        </div>
      </div>

      {/* Core Input Parameters */}
      <section className="bg-[#061822] border border-cyan-500/20 rounded-2xl p-5 space-y-4">
        <div className="flex items-center justify-between border-b border-white/5 pb-2.5">
          <span className="text-xs font-bold text-white uppercase tracking-wider">Model Parameters</span>
          <span className="text-[10px] font-mono text-slate-400">[USER ADJUSTABLE]</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {/* Input 1: IT Capacity */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs">
              <span className="text-slate-400">Compute Capacity</span>
              <span className="text-white font-mono font-semibold">{params.itLoadMW} MW</span>
            </div>
            <input
              type="range"
              min="10"
              max="200"
              step="10"
              value={params.itLoadMW}
              onChange={(e) => handleParamChange("itLoadMW", Number(e.target.value))}
              className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
            />
            <div className="text-[10px] text-slate-500 font-mono">[ASSUMED SCENARIO]</div>
          </div>

          {/* Input 2: Coolant Return Temp */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs">
              <span className="text-slate-400">Coolant Return Temp</span>
              <span className="text-amber-400 font-mono font-semibold">{params.tHot}°C</span>
            </div>
            <input
              type="range"
              min="40"
              max="65"
              step="1"
              value={params.tHot}
              onChange={(e) => handleParamChange("tHot", Number(e.target.value))}
              className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
            />
            <div className="text-[10px] text-slate-500 font-mono">[DESIGN ASSUMPTION]</div>
          </div>

          {/* Input 3: Saline Feed Flow */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs">
              <span className="text-slate-400">Saline Feed Rate</span>
              <span className="text-white font-mono font-semibold">{params.feedVolLph.toLocaleString()} L/h</span>
            </div>
            <input
              type="range"
              min="5000"
              max="150000"
              step="5000"
              value={params.feedVolLph}
              onChange={(e) => handleParamChange("feedVolLph", Number(e.target.value))}
              className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
            />
            <div className="text-[10px] text-slate-500 font-mono">[FEED WATER INPUT]</div>
          </div>

          {/* Input 4: RO Recovery */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs">
              <span className="text-slate-400">RO Recovery Ratio</span>
              <span className="text-sky-400 font-mono font-semibold">{(params.roRecoveryRate * 100).toFixed(0)}%</span>
            </div>
            <input
              type="range"
              min="0.30"
              max="0.70"
              step="0.05"
              value={params.roRecoveryRate}
              onChange={(e) => handleParamChange("roRecoveryRate", Number(e.target.value))}
              className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-sky-400"
            />
            <div className="text-[10px] text-slate-500 font-mono">[MEMBRANE PARAMETER]</div>
          </div>
        </div>
      </section>

      {/* Recalculated Key Outputs */}
      <section className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        
        {/* Output 1: Water Recovery Yield */}
        <div className="bg-[#061822] border border-cyan-500/20 rounded-2xl p-5 flex flex-col justify-between shadow-lg">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Water Recovery Yield</span>
            <span className="font-mono text-[10px] text-cyan-400">[CALCULATED]</span>
          </div>
          <div className="my-3">
            <div className="text-3xl font-bold font-mono text-white">
              {sim.hybrid.totalWaterLph.toLocaleString()} <span className="text-sm text-slate-400 font-normal">L/h</span>
            </div>
            <div className="text-xs text-cyan-300 font-mono mt-0.5">
              {sim.totalRecoveryPct.toFixed(1)}% recovery from feed
            </div>
          </div>
          <div className="text-[11px] text-slate-400 border-t border-white/5 pt-2 flex justify-between">
            <span>RO: {sim.hybrid.roWaterLph.toLocaleString()} L/h</span>
            <span>MD: {sim.hybrid.mdWaterLph.toLocaleString()} L/h</span>
          </div>
        </div>

        {/* Output 2: Waste Heat Recycled */}
        <div className="bg-[#061822] border border-cyan-500/20 rounded-2xl p-5 flex flex-col justify-between shadow-lg">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Thermal Heat Recycled</span>
            <span className="font-mono text-[10px] text-amber-400">[MODELLED]</span>
          </div>
          <div className="my-3">
            <div className="text-3xl font-bold font-mono text-white">
              {sim.thermalMWt.toFixed(1)} <span className="text-sm text-slate-400 font-normal">MWt</span>
            </div>
            <div className="text-xs text-amber-300 font-mono mt-0.5">
              70% direct-to-chip capture at {params.tHot}°C
            </div>
          </div>
          <div className="text-[11px] text-slate-400 border-t border-white/5 pt-2">
            Vapor driving force ΔPv: <span className="font-mono text-white">{sim.deltaPv.toFixed(1)} kPa</span>
          </div>
        </div>

        {/* Output 3: Modelled Distillate Quality */}
        <div className="bg-[#061822] border border-cyan-500/20 rounded-2xl p-5 flex flex-col justify-between shadow-lg">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Modelled Distillate Quality</span>
            <span className="font-mono text-[10px] text-emerald-400">[MODELLED]</span>
          </div>
          <div className="my-3">
            <div className="text-3xl font-bold font-mono text-white">
              &lt; 10 <span className="text-sm text-slate-400 font-normal">ppm TDS</span>
            </div>
            <div className="text-xs text-emerald-300 font-mono mt-0.5">
              Estimated salt rejection &gt; 99.9%
            </div>
          </div>
          <div className="text-[11px] text-slate-400 border-t border-white/5 pt-2">
            Reject brine: <span className="font-mono text-white">{sim.hybrid.roConcentrateSalinityPPM.toLocaleString(undefined, { maximumFractionDigits: 0 })} ppm</span>
          </div>
        </div>

      </section>

      {/* Mass Balance Partitioning */}
      <section className="bg-[#061822] border border-cyan-500/20 rounded-2xl p-5 space-y-3 shadow-lg">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold text-white uppercase tracking-wider">Water Mass Balance Partitioning</h3>
          <span className="text-[10px] font-mono text-slate-400">[CALCULATED FRACTIONS]</span>
        </div>

        {/* Partition bar */}
        <div className="w-full h-5 bg-[#020b12] rounded-lg overflow-hidden flex p-0.5 gap-0.5 border border-white/5">
          <div
            style={{ width: `${sim.roSharePct}%` }}
            className="h-full bg-sky-500/80 rounded flex items-center justify-center text-[10px] font-mono text-white"
          >
            RO {sim.roSharePct.toFixed(0)}%
          </div>
          <div
            style={{ width: `${sim.mdSharePct}%` }}
            className="h-full bg-emerald-500/80 rounded flex items-center justify-center text-[10px] font-mono text-slate-950 font-bold"
          >
            MD {sim.mdSharePct.toFixed(0)}%
          </div>
          {sim.brineSharePct > 1 && (
            <div
              style={{ width: `${sim.brineSharePct}%` }}
              className="h-full bg-slate-700 rounded flex items-center justify-center text-[10px] font-mono text-slate-300"
            >
              Brine {sim.brineSharePct.toFixed(0)}%
            </div>
          )}
        </div>

        <div className="grid grid-cols-3 gap-3 pt-1 text-xs">
          <div className="p-2.5 rounded-lg bg-[#020b12] border border-white/5">
            <div className="text-slate-400 text-[11px]">RO Permeate Output</div>
            <div className="font-mono font-semibold text-white mt-0.5">
              {sim.hybrid.roWaterLph.toLocaleString()} L/h
            </div>
            <div className="text-[10px] text-slate-500 font-mono">[CALCULATED]</div>
          </div>
          <div className="p-2.5 rounded-lg bg-[#020b12] border border-white/5">
            <div className="text-slate-400 text-[11px]">MD Distillate Output</div>
            <div className="font-mono font-semibold text-emerald-400 mt-0.5">
              {sim.hybrid.mdWaterLph.toLocaleString()} L/h
            </div>
            <div className="text-[10px] text-slate-500 font-mono">[CALCULATED]</div>
          </div>
          <div className="p-2.5 rounded-lg bg-[#020b12] border border-white/5">
            <div className="text-slate-400 text-[11px]">Residual Retentate</div>
            <div className="font-mono font-semibold text-slate-300 mt-0.5">
              {sim.hybrid.remainingBrineLph.toLocaleString()} L/h
            </div>
            <div className="text-[10px] text-slate-500 font-mono">[CALCULATED]</div>
          </div>
        </div>
      </section>

    </div>
  );
}
